<?php
require_once BRIDGE_CORE_SHORTCODES_PATH.'/_pie-chart-doughnut/pie-chart-doughnut.php';
