<?php
require_once BRIDGE_CORE_SHORTCODES_PATH.'/_pie-chart-with-icon/pie-chart-with-icon.php';
