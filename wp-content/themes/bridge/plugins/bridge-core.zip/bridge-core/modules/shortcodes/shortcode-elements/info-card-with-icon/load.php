<?php

include_once BRIDGE_CORE_SHORTCODES_PATH.'/info-card-with-icon/functions.php';
include_once BRIDGE_CORE_SHORTCODES_PATH.'/info-card-with-icon/info-card-with-icon.php';