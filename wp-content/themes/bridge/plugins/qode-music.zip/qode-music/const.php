<?php

define('QODE_MUSIC_VERSION', '2.0.1');
define('QODE_MUSIC_ABS_PATH', dirname(__FILE__));
define('QODE_MUSIC_REL_PATH', dirname(plugin_basename(__FILE__ )));
define('QODE_MUSIC_CPT_PATH', QODE_MUSIC_ABS_PATH.'/post-types');
define('QODE_MUSIC_SHORTCODES_PATH', QODE_MUSIC_ABS_PATH.'/shortcodes');